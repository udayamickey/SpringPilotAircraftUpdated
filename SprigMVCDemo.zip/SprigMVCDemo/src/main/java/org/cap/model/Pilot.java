package org.cap.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.validation.constraints.Future;
import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;
@Entity
public class Pilot {
	@Id 
	@GeneratedValue
	//@Range(min=1000,max=10000,message="* PilotId should be between 1000 and 10000.")
	private int pilotId;
	@NotEmpty(message="* Please enter firstName.")
	private String firstName;
	private String lastName;
	private String address;
	private String gender;
	private boolean isCertified;
	private double maxCrusing;
	@Email(message="* Please enter valid Email Id.")
	@NotEmpty(message="* please enter Email Id.")
	private String email;
	@Min(value=100000,message="* Salary min should be 1Lak.")
	private double salary;
	@Future(message=" * Date of Joining should be Future Date.")
	@DateTimeFormat(pattern="dd-MMM-yyyy")
	private Date dateOfJoing;
	private String cities;
	
	private String[] qualification;
	@ManyToMany(cascade= {CascadeType.PERSIST,CascadeType.MERGE})
	@JoinTable(name="pilot_aircraft_update",joinColumns= {@JoinColumn(name="pilotId")},
	inverseJoinColumns= {@JoinColumn(name="aircraftId")})
	private List<Aircraft> aircrafts=new ArrayList<>();
	
	public List<Aircraft> getAircrafts() {
		return aircrafts;
	}

	public void setAircrafts(List<Aircraft> aircrafts) {
		this.aircrafts = aircrafts;
	}

	public String[] getQualification() {
		return qualification;
	}

	public void setQualification(String[] qualification) {
		this.qualification = qualification;
	}

	public Pilot() {
		super();
	}

	public Pilot(int pilotId, String firstName, String lastName, String address, String gender, boolean isCertified,
			double maxCrusing, double salary, Date dateOfJoing,String cities) {
		super();
		this.pilotId = pilotId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.gender = gender;
		this.isCertified = isCertified;
		this.maxCrusing = maxCrusing;
		this.salary = salary;
		this.dateOfJoing = dateOfJoing;
		this.cities=cities;
	}

	public int getPilotId() {
		return pilotId;
	}

	public void setPilotId(int pilotId) {
		this.pilotId = pilotId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}

	public boolean isCertified() {
		return isCertified;
	}

	public void setCertified(boolean certified) {
		this.isCertified = certified;
	}

	public double getMaxCrusing() {
		return maxCrusing;
	}

	public void setMaxCrusing(double maxCrusing) {
		this.maxCrusing = maxCrusing;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public Date getDateOfJoing() {
		return dateOfJoing;
	}

	public void setDateOfJoing(Date dateOfJoing) {
		this.dateOfJoing = dateOfJoing;
	}

	public String getCities() {
		return cities;
	}

	public void setCities(String cities) {
		this.cities = cities;
	}

	@Override
	public String toString() {
		return "Pilot [pilotId=" + pilotId + ", firstName=" + firstName + ", lastName=" + lastName + ", address="
				+ address + ", gender=" + gender + ", isCertified=" + isCertified + ", maxCrusing=" + maxCrusing
				+ ", email=" + email + ", salary=" + salary + ", dateOfJoing=" + dateOfJoing + ", cities=" + cities
				+ ", qualification=" + Arrays.toString(qualification) + "]";
	}

	

	
	
	
}
